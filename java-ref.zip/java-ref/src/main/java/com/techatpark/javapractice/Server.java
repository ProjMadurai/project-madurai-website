package com.techatpark.javapractice;

import freemarker.template.*;
import java.io.*;
import org.jsoup.HttpStatusException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class Server
{

    private static final String BASE_URL = "https://www.projectmadurai.org/pmworks.html";


    public static void main(String args[]) throws IOException, TemplateException {

        Document doc = Jsoup.connect(BASE_URL).get();

        Elements boolElements = doc.select("table#sortabletable>tbody>tr");

        List<Book> books = new ArrayList<>();

        Set<String> authors = new TreeSet<>();

        Book book ;


        String bId = "" ;

        String authorsTxt = "";

        Integer weight = 1 ;

        for (Element tRow : boolElements) {
            if( !tRow.child(0).text().equals(bId)) {
                bId = tRow.child(0).text();


                book = new Book();

                book.setWeight(weight++);

                String name = tRow.child(1).text();
                name = name.replaceAll(" ","")
                        //.replaceAll(".","")
                        .replaceAll("\\)","")
                        .replaceAll("\\(","-")
                        .replaceAll("&","")
                        .replaceAll("!","")
                        .replaceAll(",","")
                        .replaceAll("\\.","")
                        .replaceAll("/","");

                System.out.println(name);
                book.setName(name);

                book.setTitle(tRow.child(1).text().replaceAll("'",""));

                authorsTxt = tRow.child(2).text().trim();
                String[] authorsTxts = authorsTxt.split("/");
                Set<String> bauthors = new TreeSet<>();
                for (String authorTxt:
                     authorsTxts) {
                    bauthors.add(authorTxt.trim());
                }
                book.setAuthors(bauthors);
                book.setGenre(tRow.child(3).text());
                books.add(book);

                authors.addAll(bauthors);
            }

        }


        Path pathToBeDeleted = Path.of("/Users/sathishkumarthiyagarajan/IdeaProjects/project-madurai-website/site/content/books");

        pathToBeDeleted.toFile().mkdirs();

        Files.walk(pathToBeDeleted)
                .sorted(Comparator.reverseOrder())
                .map(Path::toFile)
                .forEach(File::delete);

        pathToBeDeleted.toFile().mkdirs();

        books.stream().forEach(book1 -> {



            try {
                Path path = Path.of("/Users/sathishkumarthiyagarajan/IdeaProjects/project-madurai-website/site/content/books/"
                        +book1.getName()
                        +".md");
                Files.writeString(path,createBook(book1));
            } catch (IOException e) {
                e.printStackTrace();
            } catch (TemplateException e) {
                e.printStackTrace();
            }


        });





        System.out.println("SSSS");
//        Document doc = Jsoup.connect(baseUrl).get();
//        Elements newsHeadlines = doc.select("font>h2");
//        System.out.println(newsHeadlines.get(0).text());
    }

    private static String createBook(Book book) throws IOException, TemplateException {
        /* ------------------------------------------------------------------------ */
        /* You should do this ONLY ONCE in the whole application life-cycle:        */

        /* Create and adjust the configuration singleton */
        Configuration cfg = new Configuration();
        cfg.setClassForTemplateLoading(Server.class, "/");
        Template freemarkerTemplate = cfg.getTemplate("book.ftl");

        /* Merge data-model with template */
        Writer out = new StringWriter();
        freemarkerTemplate.process(book, out);

        return (out.toString());
    }

    private static Document getBookDocument(final Integer index) throws IOException {
        Document doc = null;

        try {
            doc = Jsoup.connect(BASE_URL + "pmuni"
                    +padLeftZeros(index.toString(),4)
                    +".html").get();
        }catch (HttpStatusException httpStatusException) {
            if(httpStatusException.getStatusCode() == 404) {
                doc = Jsoup.connect(BASE_URL + "pmuni"
                        +padLeftZeros(index.toString(),4)
                        +"_01.html").get();
            }
        }
        return doc;
    }

    public static String padLeftZeros(String inputString, int length) {
        if (inputString.length() >= length) {
            return inputString;
        }
        StringBuilder sb = new StringBuilder();
        while (sb.length() < length - inputString.length()) {
            sb.append('0');
        }
        sb.append(inputString);

        return sb.toString();
    }
} 