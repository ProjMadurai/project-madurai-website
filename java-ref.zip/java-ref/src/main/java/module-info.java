module my.module {
    requires java.base;
    requires org.jsoup;
    requires freemarker;
    exports com.techatpark.javapractice;
}